#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

readonly V="17.7.5"
readonly VERSION_CODE="1775"
readonly PKG="com.fabrics.app"
readonly APP_NAME="نظام الأقمشة"
readonly OUT="${HOME}/fabrics-output"
readonly WORK="${HOME}/fabrics-build-v${V}"
readonly SDK="${HOME}/android-sdk"
readonly KEYSTORE="${OUT}/release.keystore"
readonly KEY_ALIAS="fabrics"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_HTML="${1:-${SCRIPT_DIR}/index.html}"
readonly CAPACITOR_VERSION="5.7.0"
readonly ANDROID_COMPILE_SDK="34"
readonly ANDROID_BUILD_TOOLS="34.0.0"

G='\033[0;32m'; C='\033[0;36m'; R='\033[0m'; RE='\033[0;31m'
step(){ printf "\n${C}▶ %s${R}\n" "$1"; }
ok(){ printf "${G}✔${R} %s\n" "$1"; }
die(){ printf "${RE}✘${R} %s\n" "$1" >&2; exit 1; }
trap 'printf "${RE}✘${R} فشل عند السطر %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR

step "[1/12] المصدر والبيئة"
if [[ ! -f "$SOURCE_HTML" && -z "${1:-}" ]]; then
  [[ -f "${SCRIPT_DIR}/v17.7.5-PRODUCTION-2.html" ]] && SOURCE_HTML="${SCRIPT_DIR}/v17.7.5-PRODUCTION-2.html" || true
fi
[[ -f "$SOURCE_HTML" ]] || die "المصدر غير موجود: $SOURCE_HTML"
command -v node >/dev/null || die "Node.js غير مثبت"
command -v npm >/dev/null || die "npm غير مثبت"
command -v curl >/dev/null || die "curl غير مثبت"
command -v unzip >/dev/null || die "unzip غير مثبت"
command -v python3 >/dev/null || die "python3 غير مثبت"
command -v keytool >/dev/null || die "Java/keytool غير مثبت"
node -v | grep -q '^v20\.' || die "مطلوب Node.js 20.x؛ الموجود $(node -v)"
if [[ -z "${JAVA_HOME:-}" ]]; then
  if command -v java >/dev/null 2>&1; then
    JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"
  elif [[ -x /usr/lib/jvm/java-17-openjdk-amd64/bin/java ]]; then
    JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
  fi
fi
export JAVA_HOME
[[ -x "$JAVA_HOME/bin/java" ]] || die "Java 17 غير موجود: اضبط JAVA_HOME"
export PATH="$JAVA_HOME/bin:$PATH"
java -version 2>&1 | grep -q '17\.' || die "مطلوب Java 17"

step "[2/12] Android SDK"
export ANDROID_SDK_ROOT="$SDK"
export ANDROID_HOME="$SDK"
export PATH="$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$SDK/build-tools/$ANDROID_BUILD_TOOLS:$PATH"
if [[ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]]; then
  mkdir -p "$SDK/cmdline-tools"
  tmp=$(mktemp -d)
  trap 'rm -rf "$tmp"' EXIT
  curl -fsSL --retry 3 --retry-delay 2 https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -o "$tmp/ct.zip"
  rm -rf "$SDK/cmdline-tools/latest" "$SDK/cmdline-tools/cmdline-tools"
  unzip -q "$tmp/ct.zip" -d "$SDK/cmdline-tools"
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -rf "$tmp"
fi
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager --install "platform-tools" "platforms;android-${ANDROID_COMPILE_SDK}" "build-tools;${ANDROID_BUILD_TOOLS}" >/dev/null
command -v apksigner >/dev/null || die "apksigner غير موجود"
command -v aapt >/dev/null || die "aapt غير موجود؛ تحقق من Build Tools"

step "[3/12] Release keystore غير تفاعلي"
mkdir -p "$OUT"
umask 077
if [[ ! -f "$KEYSTORE" ]]; then
  KS_PASS="${FABRICS_KEYSTORE_PASSWORD:-}"
  [[ -n "$KS_PASS" ]] || die "لا يوجد keystore. أنشئه مرة واحدة مع FABRICS_KEYSTORE_PASSWORD=... ثم أعد التشغيل. لن يُطلب إدخال تفاعلي."
  keytool -genkeypair -v -keystore "$KEYSTORE" -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" -dname "CN=Fabrics App, O=Fabrics, L=Sanaa, C=YE" >/dev/null
  chmod 600 "$KEYSTORE"
else
  KS_PASS="${FABRICS_KEYSTORE_PASSWORD:-}"
  [[ -n "$KS_PASS" ]] || die "الـkeystore موجود لكن كلمة المرور غير متاحة؛ اضبط FABRICS_KEYSTORE_PASSWORD."
  keytool -list -keystore "$KEYSTORE" -storepass "$KS_PASS" -alias "$KEY_ALIAS" >/dev/null || die "كلمة مرور keystore غير صحيحة"
fi

step "[4/12] إنشاء مشروع نظيف"
rm -rf "$WORK"
mkdir -p "$WORK/www/lib"
cp "$SOURCE_HTML" "$WORK/www/index.html"
cp "$SCRIPT_DIR/manifest.json" "$WORK/www/manifest.json"
cp "$SCRIPT_DIR/icon.svg" "$WORK/www/icon.svg"
mkdir -p "$WORK/www/lib"
python3 - "$WORK/www/index.html" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); s=p.read_text(encoding='utf-8')
# Known CDN dependencies are downloaded locally by this builder.
s=s.replace('https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js','./lib/html2pdf.bundle.min.js')
# Print document policy: only embedded data:image sources are allowed; all hrefs are stripped.
pat=r"querySelectorAll\('\[src\],\[href\]'\)\.forEach\(n=>\{.*?\}\);"
rep="querySelectorAll('[src],[href]').forEach(n=>{const a=n.hasAttribute('src')?'src':'href',v=(n.getAttribute(a)||'').trim();if(a==='src'){if(!/^data:image\\/(png|jpeg|jpg|gif|webp);base64,/i.test(v))n.removeAttribute(a);}else n.removeAttribute(a);});"
s=re.sub(pat,rep,s,count=1,flags=re.S)
try:
    p.write_text(s,encoding='utf-8')
except Exception as e:
    raise SystemExit(f'Failed writing HTML: {e}')
PY
cp "$SCRIPT_DIR/lib/html2pdf.bundle.min.js" "$WORK/www/lib/html2pdf.bundle.min.js"
[[ -s "$WORK/www/lib/html2pdf.bundle.min.js" ]] || die "محرك PDF المحلي غير موجود"
cat > "$WORK/package.json" <<JSON
{"name":"fabrics-app","version":"${V}","private":true,"dependencies":{"@capacitor/android":"${CAPACITOR_VERSION}","@capacitor/core":"${CAPACITOR_VERSION}"},"devDependencies":{"@capacitor/cli":"${CAPACITOR_VERSION}"}}
JSON
cat > "$WORK/capacitor.config.json" <<JSON
{"appId":"${PKG}","appName":"${APP_NAME}","webDir":"www","bundledWebRuntime":false,"android":{"allowMixedContent":false},"server":{"androidScheme":"https"}}
JSON

step "[5/12] Capacitor"
cd "$WORK"
npm install --package-lock-only --no-audit --no-fund >/dev/null
npm ci --no-audit --no-fund >/dev/null
npx cap add android >/dev/null
npx cap sync android >/dev/null

step "[6/12] NativePrint + FileProvider"
MAIN=$(find android/app/src/main/java -name MainActivity.java -print -quit)
[[ -n "$MAIN" ]] || die "MainActivity.java غير موجود"
JAVA_DIR=$(dirname "$MAIN")
PKG_NAME=$(sed -n 's/^package \(.*\);/\1/p' "$MAIN" | head -1)
[[ -n "$PKG_NAME" ]] || die "تعذر تحديد package"
MANIFEST="android/app/src/main/AndroidManifest.xml"
cat > "$JAVA_DIR/NativePrintPlugin.java" <<JEOF
package $PKG_NAME;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.JSObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

@CapacitorPlugin(name="NativePrint")
public class NativePrintPlugin extends Plugin {
  private WebView printWebView;
  @PluginMethod public void printHtml(PluginCall call) {
    final String html=call.getString("html",""); final String jobName=call.getString("jobName","Fabrics Document");
    if(html.isEmpty()){call.reject("empty html");return;}
    getActivity().runOnUiThread(()->{
      try{
        if(printWebView!=null){printWebView.destroy();printWebView=null;}
        printWebView=new WebView(getActivity());
        printWebView.getSettings().setJavaScriptEnabled(false);
        printWebView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){try{
          PrintManager pm=(PrintManager)getActivity().getSystemService(Context.PRINT_SERVICE);
          PrintDocumentAdapter adapter=view.createPrintDocumentAdapter(jobName);
          pm.print(jobName,adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
          call.resolve(new JSObject().put("success",true));
        }catch(Exception e){call.reject("print failed: "+e.getMessage());}}});
        printWebView.loadDataWithBaseURL("file:///android_asset/",html,"text/html","UTF-8",null);
      }catch(Exception e){call.reject("print failed: "+e.getMessage());}
    });
  }
  @PluginMethod public void shareHtml(PluginCall call){
    final String html=call.getString("html",""); final String filename=call.getString("filename","fabrics-document.html");
    if(html.isEmpty()){call.reject("empty html");return;}
    try{String safe=filename.replaceAll("[^A-Za-z0-9._-]","_"); File f=new File(getActivity().getCacheDir(),safe);
      try(FileOutputStream out=new FileOutputStream(f)){out.write(html.getBytes(StandardCharsets.UTF_8));}
      Uri uri=FileProvider.getUriForFile(getActivity(),getActivity().getPackageName()+".fileprovider",f);
      Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/html");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      getActivity().startActivity(Intent.createChooser(send,"مشاركة"));call.resolve(new JSObject().put("success",true));
    }catch(Exception e){call.reject("share failed: "+e.getMessage());}
  }
  @Override protected void handleOnDestroy(){if(printWebView!=null){printWebView.destroy();printWebView=null;}super.handleOnDestroy();}
}
JEOF
cat > "$MAIN" <<MEOF
package $PKG_NAME;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity { @Override public void onCreate(Bundle savedInstanceState){ registerPlugin(NativePrintPlugin.class); super.onCreate(savedInstanceState); } }
MEOF
mkdir -p android/app/src/main/res/xml
cat > android/app/src/main/res/xml/file_paths.xml <<'XML'
<?xml version="1.0" encoding="utf-8"?><paths xmlns:android="http://schemas.android.com/apk/res/android"><cache-path name="cache" path="."/><files-path name="files" path="."/></paths>
XML
python3 - "$MANIFEST" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); x=p.read_text(encoding='utf-8')
if 'android.permission.INTERNET' not in x:x=re.sub(r'(<manifest[^>]*>)',r'\1\n<uses-permission android:name="android.permission.INTERNET"/>',x,1)
if 'androidx.core.content.FileProvider' not in x:x=x.replace('</application>','''<provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.fileprovider" android:exported="false" android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths"/></provider></application>''',1)
try:
    p.write_text(x,encoding='utf-8')
except Exception as e:
    raise SystemExit(f'Failed writing manifest: {e}')
PY

step "[7/12] Release signing"
python3 - "$WORK/android/app/build.gradle" "$KEYSTORE" "$KEY_ALIAS" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]);x=p.read_text()
ks=sys.argv[2].replace('\\','\\\\').replace('"','\\"'); alias=sys.argv[3]
x=re.sub(r'versionCode\s+\d+', 'versionCode 1775', x)
x=re.sub(r'versionName\s+"[^"]*"', 'versionName "17.7.5"', x)
x=x.replace('JavaVersion.VERSION_1_8','JavaVersion.VERSION_17').replace('JavaVersion.VERSION_11','JavaVersion.VERSION_17')
if 'signingConfigs {' not in x:
    x=x.replace('android {','''android {
    signingConfigs {
        release {
            storeFile file("'''+ks+'''")
            storePassword System.getenv("FABRICS_KEYSTORE_PASSWORD")
            keyAlias "'''+alias+'''"
            keyPassword System.getenv("FABRICS_KEYSTORE_PASSWORD")
        }
    }''',1)
# Ensure exactly one release block is present with signingConfig. If generated template has one, augment it.
m=re.search(r'buildTypes\s*\{',x)
if not m: raise SystemExit('buildTypes غير موجود')
start=m.end(); depth=1;i=start
while i<len(x) and depth:
    if x[i]=='{': depth+=1
    elif x[i]=='}': depth-=1
    i+=1
block=x[start:i-1]
if 'release {' not in block:
    x=x[:start]+'\n        release { signingConfig signingConfigs.release; minifyEnabled false; shrinkResources false }\n'+x[start:]
else:
    x=re.sub(r'(release\s*\{)(?![^{}]*signingConfig)([^{}]*)\}',lambda m:m.group(1)+' signingConfig signingConfigs.release; minifyEnabled false; shrinkResources false; '+m.group(2)+'}',x,count=1)
try:
    p.write_text(x)
except Exception as e:
    raise SystemExit(f'Failed writing Gradle: {e}')
PY

grep -q 'versionCode 1775' android/app/build.gradle || die 'versionCode 1775 غير موجود'
grep -q 'versionName "17.7.5"' android/app/build.gradle || die 'versionName 17.7.5 غير موجود'
grep -q 'signingConfig signingConfigs.release' android/app/build.gradle || die 'release signing غير مضبوط'
python3 - android/app/build.gradle <<'PY'
from pathlib import Path
import re,sys
x=Path(sys.argv[1]).read_text()
m=re.search(r'buildTypes\s*\{',x)
if not m: raise SystemExit('buildTypes missing')
start=m.end(); depth=1; i=start
while i<len(x) and depth:
    if x[i]=='{': depth+=1
    elif x[i]=='}': depth-=1
    i+=1
block=x[start:i-1]
rels=[]; j=0
while j<len(block):
    mm=re.search(r'\brelease\s*\{',block[j:])
    if not mm: break
    a=j+mm.start(); k=j+mm.end(); d=1
    while k<len(block) and d:
        if block[k]=='{': d+=1
        elif block[k]=='}': d-=1
        k+=1
    rels.append(block[a:k]); j=k
if len(rels)!=1: raise SystemExit(f'RELEASE_ASSERT failed: {len(rels)}')
if 'signingConfig signingConfigs.release' not in rels[0]: raise SystemExit('release signingConfig missing')
if 'FABRICS_KEYSTORE_PASSWORD' not in x: raise SystemExit('keystore password must come from environment')
PY

step "[8/12] فحص HTML وJavaScript"
python3 - "$WORK/www/index.html" <<'PY'
from pathlib import Path
import re,sys,subprocess,tempfile
s=Path(sys.argv[1]).read_text(encoding='utf-8')
checks={
'no CDN html2pdf':'cdnjs.cloudflare.com/ajax/libs/html2pdf' not in s,
'no CDN lz-string':'cdnjs.cloudflare.com/ajax/libs/lz-string' not in s,
'NativePrint hook':'NativePrint' in s,
'login':'loginPin' in s,
'backup':'exportBackup' in s,
'no default pins': not bool(re.search(r"['\"](123456|999999)['\"]",s)),
}
for k,v in checks.items():print(('OK ' if v else 'FAIL ')+k)
if not all(checks.values()):raise SystemExit(1)
blocks=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',s,re.S|re.I)
Path('/tmp/fabrics-js-check.js').write_text('\n'.join(blocks),encoding='utf-8')
r=subprocess.run(['node','--check','/tmp/fabrics-js-check.js'],capture_output=True,text=True)
if r.returncode: print(r.stderr); raise SystemExit(r.returncode)
PY

step "[9/12] Release build"
cd "$WORK/android"
chmod +x gradlew
./gradlew clean assembleRelease --no-daemon --stacktrace
APK="$WORK/android/app/build/outputs/apk/release/app-release.apk"
[[ -f "$APK" ]] || die "app-release.apk غير موجود"

step "[10/12] APK signature + metadata"
apksigner verify --verbose --print-certs "$APK"
SIG=$(apksigner verify --verbose "$APK" 2>&1)
printf '%s\n' "$SIG" | grep -q 'Verified using v2 scheme' || die "V2 signature verification failed"
keytool -printcert -jarfile "$APK" >/dev/null 2>&1 || printf '%s\n' "$SIG" | grep -q 'Verified using v2 scheme' || die "certificate verification failed"
aapt dump badging "$APK" | grep -q "package: name='${PKG}'" || die "package mismatch"
aapt dump badging "$APK" | grep -q "versionCode='${VERSION_CODE}'" || die "versionCode mismatch"
aapt dump badging "$APK" | grep -q "versionName='${V}'" || die "versionName mismatch"

step "[11/12] Final artifact"
FINAL="$OUT/fabrics-v${V}.apk"
cp "$APK" "$FINAL"
chmod 644 "$FINAL"
SHA=$(sha256sum "$FINAL" | awk '{print $1}')
SIZE=$(du -h "$FINAL" | awk '{print $1}')
cat > "$OUT/fabrics-v${V}.build.txt" <<TXT
APP=Fabrics
VERSION=${V}
VERSION_CODE=${VERSION_CODE}
PACKAGE=${PKG}
APK=${FINAL}
SHA256=${SHA}
SIZE=${SIZE}
BUILD_TYPE=release
SIGNED=yes
V2_SIGNATURE=verified
SOURCE=${SOURCE_HTML}
CAPACITOR=${CAPACITOR_VERSION}
COMPILE_SDK=${ANDROID_COMPILE_SDK}
BUILD_TOOLS=${ANDROID_BUILD_TOOLS}
TXT

step "[12/12] النتيجة"
printf 'APK=%s\nSIZE=%s\nSHA256=%s\n' "$FINAL" "$SIZE" "$SHA"
printf 'ملاحظة: هذا السكريبت يرفض الادعاء بالتحقق من جهاز فعلي؛ يلزم تثبيت/اختبار الجهاز بعد البناء.\n'
