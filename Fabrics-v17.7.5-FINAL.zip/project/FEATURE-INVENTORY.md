# Feature Inventory — Fabrics v17.7.5

Verified against the preserved source snapshot by comparing all HTML IDs and all App onclick entry points.

- Navigation: home, workers, materials, purchases, issue, supply, payments, reports, movement, search, deleted, backup, settings, audit, help.
- Data: worker/material/purchase/issue/supply/payment entry and validation.
- Editing: worker name, material name, opening balance, material cost, issue, supply, payment.
- Lifecycle: delete, cancel, restore, cleanup, copy.
- Accounting: journal generation/rebuild, balance verification, opening-balance journal, issue journal, supply-wage journal, payment journal.
- Storage: IndexedDB, OPFS, emergency localStorage, backup/import/export, migration.
- Reporting: inventory, custody, matching, worker statement, trial balance, journal, comprehensive reports.
- Search and filtering.
- Printing: report printing, document preview, native print hook, PDF, PDF sharing.
- Offline assets: manifest, icon, local PDF engine.
- Authentication and recovery-code flows.
- Self-tests and audit log.

Feature parity check against the preserved source snapshot:
- HTML IDs removed: **0**
- App onclick entry points removed: **0**
