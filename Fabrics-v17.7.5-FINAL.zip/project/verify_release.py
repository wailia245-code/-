#!/usr/bin/env python3
import json,re,sys,zipfile,hashlib,subprocess,tempfile,os
from pathlib import Path
root=Path(__file__).resolve().parent
html=root/'index.html'
results={}
s=html.read_text(encoding='utf-8')
# HTML structure (ignore literal HTML embedded inside scripts/styles).
x=re.sub(r'<script\b[^>]*>.*?</script>','',s,flags=re.S|re.I)
x=re.sub(r'<style\b[^>]*>.*?</style>','',x,flags=re.S|re.I)
x=re.sub(r'<!--.*?-->','',x,flags=re.S)
tags=re.findall(r'<\s*(/?)\s*([A-Za-z][\w:-]*)\b[^>]*?>',x)
stack=[]; bad=[]; void={'meta','link','input','img','br','hr','area','base','col','embed','param','source','track','wbr'}
for closing,name in tags:
    n=name.lower()
    if n in void: continue
    if closing:
        if not stack or stack[-1]!=n: bad.append((n,stack[-5:]))
        else: stack.pop()
    else: stack.append(n)
results['HTML']='PASS' if not stack and not bad and s.startswith('<!DOCTYPE html>') and '</head>\n<body>' in s and s.rstrip().endswith('</body>\n</html>') else 'FAIL'
ids=re.findall(r'\bid=["\']([^"\']+)',s,re.I)
from collections import Counter
results['DUPLICATE_IDS']='NONE' if not [x for x in Counter(ids).values() if x>1] else 'FOUND'
refs=re.findall(r'<(?:script|link|img|iframe)[^>]+(?:src|href)=["\']([^"\']+)',s,re.I)
missing=[r for r in refs if r.startswith('./') and not (root/r).exists()]
results['LOCAL_REFERENCES']='PASS' if not missing else 'FAIL:'+','.join(missing)
results['EXTERNAL_RUNTIME']='PASS' if not any('cdnjs.cloudflare.com' in u for u in re.findall(r'https?://[^"\'\s<>]+',s)) else 'FAIL'
blocks=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',s,re.S|re.I)
js=Path('/tmp/fabrics-final-js.js'); js.write_text('\n'.join(blocks),encoding='utf-8')
r=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
results['JAVASCRIPT']='PASS' if r.returncode==0 else 'FAIL'
r=subprocess.run(['bash','-n',str(root/'build-fabrics-v17.7.5.sh')],capture_output=True,text=True)
results['BASH']='PASS' if r.returncode==0 else 'FAIL'
workflow=root/'.github/workflows/android-release.yml'
results['WORKFLOW']='PASS' if workflow.exists() and 'actions/upload-artifact@v4' in workflow.read_text() and 'if-no-files-found: error' in workflow.read_text() else 'FAIL'
required=['IndexedDB','OPFS','localStorage','backup','restore','editMaterial','saveSupply','editSupply','printNative','generatePDF','sharePDF','exportBackup','Journal.rebuild','searchQuery']
results['FEATURE_HOOKS']='PASS' if all(x in s for x in required) else 'FAIL'
results['PDF_ENGINE']='PASS' if (root/'lib/html2pdf.bundle.min.js').stat().st_size>1000 else 'FAIL'
results['MANIFEST']='PASS' if (root/'manifest.json').exists() and (root/'icon.svg').exists() else 'FAIL'
print(json.dumps(results,ensure_ascii=False,indent=2))
if any(v=='FAIL' or str(v).startswith('FAIL:') for v in results.values()): sys.exit(1)
