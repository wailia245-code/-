# Fabrics v17.7.5 — Production Release

Canonical entry: `index.html`

Package: `com.fabrics.app`
Version: `17.7.5` / versionCode `1775`

## Production rules implemented
- Supply records are **basic production pieces only**.
- Supply wages = supplied basic pieces × piece wage.
- Issue basic and additional quantities remain separate.
- Issue document total = **basic pieces only**; additional quantities remain per material.
- Supply quantities increase warehouse stock and reduce worker custody.
- Material name, opening balance, and unit cost can be edited; opening journal is rebuilt without duplication.
- IndexedDB, OPFS, and emergency localStorage snapshots are considered together and the newest valid snapshot is selected.
- Printing, native printing, PDF, and PDF sharing hooks remain available.
- Runtime dependencies used by the exported app are local.

## Build
Run `build-fabrics-v17.7.5.sh` with Node 20 and Java 17 plus an Android SDK-capable environment. The script produces a signed release APK when `FABRICS_KEYSTORE_PASSWORD` is supplied.

## GitHub Actions
`.github/workflows/android-release.yml` builds and verifies the signed APK. Production signing requires repository secrets:
- `FABRICS_KEYSTORE_PASSWORD`
- `FABRICS_KEYSTORE_BASE64` (existing release keystore; optional on first build, when the builder can create one)
